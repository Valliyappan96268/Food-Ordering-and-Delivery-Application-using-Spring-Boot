package com.example.demowithmany.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demowithmany.model.Category;
import com.example.demowithmany.model.Product;

public interface ProductRepository extends JpaRepository<Product, Long> {
    List<Product> findByCategory(Category category);
}
