package com.example.demowithmany;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemowithmanyApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemowithmanyApplication.class, args);
	}

}
