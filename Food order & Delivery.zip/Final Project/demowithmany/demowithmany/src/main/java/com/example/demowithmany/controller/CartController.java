package com.example.demowithmany.controller;


import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.*;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.demowithmany.model.*;
import com.example.demowithmany.service.*;

@Controller
public class CartController {
	
	  @Autowired
	    CartService cartService;

	    @PostMapping("/add/{productId}")
	    public String addToCart(@PathVariable Long productId, Principal principal) {
	        cartService.addToCart(principal.getName(), productId);
	        return "redirect:/cart/view";
	    }

	    @GetMapping("/view")
	    public String viewCart(Model model, Principal principal) {
	        model.addAttribute("items", cartService.getCartItems(principal.getName()));
	        return "cart";
	    }

}
