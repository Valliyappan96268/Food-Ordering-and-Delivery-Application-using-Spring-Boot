package com.example.demowithmany.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demowithmany.model.OrderItem;

public interface OrderItemRepository extends JpaRepository<OrderItem, Long> { }

